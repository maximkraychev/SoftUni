const section = document.querySelector('#home-page');

export function showHome(context) {
    
    context.showSection(section)
}